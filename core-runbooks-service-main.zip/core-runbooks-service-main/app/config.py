import os

class Config:
    SECRET_KEY = 'you-should-change-this'
    SQLALCHEMY_DATABASE_URI = (
            
        )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
