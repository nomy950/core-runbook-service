# core-runbooks-service
This service is owned by core automation team.
